#!/usr/bin/python3

###############################################################################
#
# ASIS CTF 2016
# P1kachu
# Forensics 109 - firtog
#
###############################################################################

from os import urandom
from hashlib import md5
import io

# The encrypted string we found
encrypted = io.StringIO("41608a606a63201245f1020d205f1612147463d85d125c1416635c854c74d172010105c14f8555d125c3c")


flag_dec = ''
while True:
    c = encrypted.read(1)

    # For some reasons, running the script and printing the characters
    # shows that 'f' or 'd' will often (always?) remain alone
    # Every other byte will have two chars
    if (c != 'f' and c != 'd'):
        c += encrypted.read(1)

    # End of input
    if c == '':
        break

    # Bruteforce
    for x in range(0x00, 0xff):
        tmp = hex(pow(x, 65537, 143))[2:]
        if tmp == c:
            flag_dec += chr(x)
            print(flag_dec)
            break;

