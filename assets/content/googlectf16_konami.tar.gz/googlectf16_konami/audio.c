#include <stdio.h>

#define __int8 char
#define _BYTE char

// SHOULD BE THE HARDCODED BUFFER
char flag[] = "TMP";

char check;
char state = 5;
char buffer[32];
char *pos = buffer;

char *cross_ptr = "%hn";

//----- (00000000004009C7) ----------------------------------------------------
int output_flag()
{
  char *v1; // [sp+0h] [bp-10h]@1
 char *v2; // [sp+8h] [bp-8h]@1

  v2 = flag;
  v1 = buffer;
  while ( *v2 )
    putchar((*v2++ ^ *v1++));
  return putchar('\n');
}

int main(int argc, const char **argv, const char **envp)
{
        unsigned __int8 v3; // ST1F_1@2
        char v1, v0;



        while ( 1 ) {
                *(_BYTE *)pos = state;
                pos = (char *)pos + 1;
                if ( (_BYTE *)pos - buffer > 32 )
                        pos = buffer;
                check ^= state;

                switch ( getchar() ) {
                        default:
                                continue;
                        case 'u':
                                state = state * 3;
                                break;
                        case 'd':
                                state = state*4 - state/2;
                                break;
                        case 'l':
                                state *= 2;
                                break;
                        case 'r':
                                state = (state / 8) | (state * 32);
                                break;
                        case 'b':
                                state = ~state;
                                break;
                        case 'a':

                                if ( *(_BYTE *)cross_ptr == check ) {
                                        check = 0;
                                        cross_ptr = (char *)cross_ptr + 1;
                                        if ( (_BYTE *)pos - buffer > 29 )
                                                output_flag();
                                } else {
                                        puts("loser");
                                        // reset();
                                }
                                break;
                }
        }


        return 0;
}

