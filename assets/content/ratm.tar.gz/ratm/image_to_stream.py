#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

# Copyright Pluggi 2016

import os
import sys

from PIL import Image
from array import array

im = Image.open(sys.argv[1])
out = sys.argv[2]

try:
    os.remove(out)
except OSError:
    ...

for i, band in enumerate(im.getbands()):
    with open(out, 'ab') as f:
        array('f', im.getdata(i)).tofile(f)
