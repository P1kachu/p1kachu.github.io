#!/usr/bin/env python2

from __future__ import print_function

import sys
import numpy as np

from keras.models import Sequential
from keras.layers import ZeroPadding2D
from keras.layers.core import Dense, Dropout, Flatten
from keras.layers.convolutional import Convolution2D, MaxPooling2D

m = Sequential()

width = 320
height = 240

m.add(ZeroPadding2D((1,1),input_shape=(3,height,width)))
m.add(Convolution2D(64, 6, 6, activation='relu'))
m.add(ZeroPadding2D((1,1)))
m.add(Convolution2D(64, 6, 6, activation='relu'))
m.add(MaxPooling2D((4,4), strides=(4,4)))

m.add(Convolution2D(64, 4, 4, activation='relu'))
m.add(ZeroPadding2D((1,1)))
m.add(Convolution2D(64, 4, 4, activation='relu'))
m.add(MaxPooling2D((3,3), strides=(3,3)))

m.add(Convolution2D(128, 3, 3, activation='relu'))
m.add(ZeroPadding2D((1,1)))
m.add(Convolution2D(128, 3, 3, activation='relu'))
m.add(MaxPooling2D((3,3), strides=(3,3)))

m.add(Convolution2D(192, 3, 3, activation='relu'))
m.add(ZeroPadding2D((1,1)))
m.add(Convolution2D(192, 3, 3, activation='relu'))
m.add(MaxPooling2D((3,3), strides=(3,3)))

m.add(Flatten())
m.add(Dropout(0.3))
m.add(Dense(256, activation='relu'))
m.add(Dropout(0.4))
m.add(Dense(256, activation='relu'))
m.add(Dropout(0.4))
m.add(Dense(2, activation='softmax'))

m.compile(optimizer='sgd', loss='binary_crossentropy')

m.load_weights("model")

def is_good_image(image):
    bad,good = list(m.predict(np.array([image]))[0])
    print(good)
    return good > 0.99

#read each of the 320x240 pixels, in red, green, and blue 320x240x3
a = 320 * 240 * 4
with open(sys.argv[1], 'rb') as f:
    red   = np.fromstring(f.read(a), dtype='float32').reshape(240,320)
    green = np.fromstring(f.read(a), dtype='float32').reshape(240,320)
    blue  = np.fromstring(f.read(a), dtype='float32').reshape(240,320)
image = np.array([red, green, blue])
if is_good_image(image):
    print('YAY!!!')
else:
    print('Boooh......')
